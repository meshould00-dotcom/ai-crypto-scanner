import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, ScrollView, Animated, SafeAreaView } from 'react-native';
import AdMobBannerComponent from '../components/AdMobBanner';
import { Ionicons } from '@expo/vector-icons';
import GradientBackground from '../components/GradientBackground';
import NeonButton from '../components/NeonButton';
import GlassCard from '../components/GlassCard';
import { COLORS, SPACING, FONT_SIZES, BORDER_RADIUS } from '../constants/theme';

export default function HomeScreen({ navigation }) {
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  return (
    <GradientBackground>
      <SafeAreaView style={styles.safeArea}>
        <ScrollView 
          style={styles.container}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}
        >
          {/* Header */}
          <Animated.View 
            style={[
              styles.header,
              { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }
            ]}
          >
            <View style={styles.logoContainer}>
              <Ionicons name="scan-circle" size={48} color={COLORS.neonPurple} />
            </View>
            <Text style={styles.title}>AI Crypto Scanner</Text>
            <Text style={styles.subtitle}>Powered by Gemini AI</Text>
          </Animated.View>

          {/* Main Action Buttons */}
          <Animated.View 
            style={[
              styles.actionsContainer,
              { opacity: fadeAnim }
            ]}
          >
            <NeonButton
              title="Scan with Camera"
              size="large"
              icon={<Ionicons name="camera" size={24} color={COLORS.text} />}
              onPress={() => navigation.navigate('CameraScan')}
              style={styles.mainButton}
            />

            <NeonButton
              title="Upload from Gallery"
              size="large"
              variant="secondary"
              icon={<Ionicons name="images" size={24} color={COLORS.text} />}
              onPress={() => navigation.navigate('Upload')}
              style={styles.mainButton}
            />
          </Animated.View>

          {/* Features */}
          <View style={styles.featuresContainer}>
            <Text style={styles.sectionTitle}>Features</Text>
            
            <GlassCard style={styles.featureCard}>
              <View style={styles.featureIcon}>
                <Ionicons name="analytics" size={32} color={COLORS.neonPurple} />
              </View>
              <View style={styles.featureContent}>
                <Text style={styles.featureTitle}>AI Analysis</Text>
                <Text style={styles.featureDescription}>
                  Advanced AI analyzes your charts and provides buy/sell signals
                </Text>
              </View>
            </GlassCard>

            <GlassCard style={styles.featureCard}>
              <View style={styles.featureIcon}>
                <Ionicons name="trending-up" size={32} color={COLORS.neonBlue} />
              </View>
              <View style={styles.featureContent}>
                <Text style={styles.featureTitle}>Entry & Exit Points</Text>
                <Text style={styles.featureDescription}>
                  Get precise entry, stop-loss, and take-profit levels
                </Text>
              </View>
            </GlassCard>

            <GlassCard style={styles.featureCard}>
              <View style={styles.featureIcon}>
                <Ionicons name="shield-checkmark" size={32} color={COLORS.neonGreen} />
              </View>
              <View style={styles.featureContent}>
                <Text style={styles.featureTitle}>Risk Assessment</Text>
                <Text style={styles.featureDescription}>
                  Understand the risk level of each trade opportunity
                </Text>
              </View>
            </GlassCard>
          </View>

          {/* Banner Ad */}
          <AdMobBannerComponent unitType="home" />
        </ScrollView>
      </SafeAreaView>
    </GradientBackground>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  container: {
    flex: 1,
  },
  contentContainer: {
    padding: SPACING.lg,
    paddingBottom: SPACING.xxl,
  },
  header: {
    alignItems: 'center',
    marginBottom: SPACING.xl,
    marginTop: SPACING.lg,
  },
  logoContainer: {
    marginBottom: SPACING.md,
  },
  title: {
    fontSize: FONT_SIZES.xxxl,
    fontWeight: 'bold',
    color: COLORS.text,
    marginBottom: SPACING.xs,
  },
  subtitle: {
    fontSize: FONT_SIZES.md,
    color: COLORS.textSecondary,
  },
  actionsContainer: {
    marginBottom: SPACING.xl,
    gap: SPACING.md,
  },
  mainButton: {
    width: '100%',
  },
  featuresContainer: {
    marginBottom: SPACING.xl,
  },
  sectionTitle: {
    fontSize: FONT_SIZES.xl,
    fontWeight: 'bold',
    color: COLORS.text,
    marginBottom: SPACING.md,
  },
  featureCard: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: SPACING.md,
    padding: SPACING.lg,
  },
  featureIcon: {
    marginRight: SPACING.md,
  },
  featureContent: {
    flex: 1,
  },
  featureTitle: {
    fontSize: FONT_SIZES.lg,
    fontWeight: 'bold',
    color: COLORS.text,
    marginBottom: SPACING.xs,
  },
  featureDescription: {
    fontSize: FONT_SIZES.sm,
    color: COLORS.textSecondary,
    lineHeight: 20,
  },
  adContainer: {
    height: 50,
    backgroundColor: COLORS.glass,
    borderRadius: BORDER_RADIUS.md,
    borderWidth: 1,
    borderColor: COLORS.glassBorder,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: SPACING.md,
  },
  adText: {
    color: COLORS.textTertiary,
    fontSize: FONT_SIZES.sm,
  },
});
