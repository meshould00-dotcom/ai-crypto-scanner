import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, SafeAreaView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORS, SPACING, FONT_SIZES, BORDER_RADIUS } from '../constants/theme';
import GradientBackground from '../components/GradientBackground';
import GlassCard from '../components/GlassCard';
import NeonButton from '../components/NeonButton';
import LoadingSpinner from '../components/LoadingSpinner';
import AdMobBannerComponent from '../components/AdMobBanner';
import { analyzeChart } from '../services/geminiApi';
import { saveToHistory } from '../services/storage';
import { shouldShowInterstitial } from '../services/adMobService';
import { AdMobInterstitial, AdMobRewarded } from 'expo-ads-admob';

// Mock Data Structure for quick reference
const MOCK_ANALYSIS = {
  trend: 'bullish',
  decision: 'BUY',
  entry: '0.5234 USDT',
  stop_loss: '0.4980 USDT',
  take_profit: {
    tp1: '0.5500 USDT',
    tp2: '0.5750 USDT',
    tp3: '0.6000 USDT',
  },
  risk_level: 'medium',
  analysis_text: 'The chart shows a clear breakout from a descending triangle pattern, supported by high volume. The RSI is moving into overbought territory, but momentum suggests a strong continuation to TP1. Risk is medium due to overall market volatility.',
};

export default function ResultScreen({ route, navigation }) {
  const { imageUri } = route.params;
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [unlocked, setUnlocked] = useState(false);

  useEffect(() => {
    const runAnalysis = async () => {
      // 1. Show Interstitial Ad
      if (shouldShowInterstitial()) {
        try {
          await AdMobInterstitial.setAdUnitID('ca-app-pub-3940256099942544/1033173712'); // Test ID
          await AdMobInterstitial.requestAdAsync({ servePersonalizedAds: true });
          await AdMobInterstitial.showAdAsync();
        } catch (e) {
          console.log('Interstitial Ad Error:', e);
        }
      }

      // 2. Run AI Analysis
      const result = await analyzeChart(imageUri);
      
      if (result.success) {
        const fullAnalysis = { ...result.data, imageUri };
        setAnalysis(fullAnalysis);
        await saveToHistory(fullAnalysis);
      } else {
        setError(result.error);
        // Fallback to mock data for demonstration if API fails
        setAnalysis({ ...MOCK_ANALYSIS, imageUri });
        await saveToHistory({ ...MOCK_ANALYSIS, imageUri });
      }
      setLoading(false);
    };

    runAnalysis();
  }, [imageUri]);

  const handleUnlockFullAnalysis = async () => {
    try {
      await AdMobRewarded.setAdUnitID('ca-app-pub-3940256099942544/5224354917'); // Test ID
      await AdMobRewarded.requestAdAsync();
      
      AdMobRewarded.addEventListener('rewardedVideoUserDidEarnReward', () => {
        setUnlocked(true);
      });

      await AdMobRewarded.showAdAsync();
    } catch (e) {
      console.log('Rewarded Ad Error:', e);
      // Fallback for testing: unlock if ad fails
      setUnlocked(true);
    }
  };

  const AnalysisCard = ({ title, value, color = COLORS.text }) => (
    <GlassCard style={styles.analysisCard}>
      <Text style={styles.cardTitle}>{title}</Text>
      <Text style={[styles.cardValue, { color }]}>{value}</Text>
    </GlassCard>
  );

  const getDecisionColor = (decision) => {
    if (!decision) return COLORS.text;
    if (decision.toUpperCase() === 'BUY') return COLORS.neonGreen;
    if (decision.toUpperCase() === 'SELL') return COLORS.danger;
    return COLORS.neonBlue;
  };

  if (loading) {
    return <LoadingSpinner fullScreen message="Analyzing chart with Gemini AI..." />;
  }

  if (error && !analysis) {
    return (
      <GradientBackground>
        <SafeAreaView style={styles.safeArea}>
          <View style={styles.errorContainer}>
            <Ionicons name="warning" size={64} color={COLORS.danger} />
            <Text style={styles.errorTitle}>Analysis Failed</Text>
            <Text style={styles.errorMessage}>{error}</Text>
            <NeonButton
              title="Go Home"
              onPress={() => navigation.replace('MainTabs')}
              style={{ marginTop: SPACING.xl }}
            />
          </View>
        </SafeAreaView>
      </GradientBackground>
    );
  }

  return (
    <GradientBackground>
      <SafeAreaView style={styles.safeArea}>
        <ScrollView contentContainerStyle={styles.scrollContent}>
          <View style={styles.header}>
            <NeonButton
              title="Home"
              variant="outline"
              size="small"
              icon={<Ionicons name="home" size={20} color={COLORS.neonPurple} />}
              onPress={() => navigation.replace('MainTabs')}
              style={{ width: 100 }}
            />
            <Text style={styles.pageTitle}>AI Analysis Result</Text>
          </View>

          {/* Chart Image Preview */}
          <GlassCard style={styles.imageCard}>
            <Text style={styles.sectionTitle}>Chart Scanned</Text>
            <Image source={{ uri: imageUri }} style={styles.chartImage} />
          </GlassCard>

          {/* Key Metrics */}
          <View style={styles.metricsContainer}>
            <AnalysisCard title="Decision" value={analysis.decision} color={getDecisionColor(analysis.decision)} />
            <AnalysisCard title="Trend" value={analysis.trend} color={analysis.trend === 'bullish' ? COLORS.neonGreen : COLORS.neonBlue} />
            <AnalysisCard title="Entry Price" value={analysis.entry} color={COLORS.neonPurple} />
            <AnalysisCard title="Stop Loss (SL)" value={analysis.stop_loss} color={COLORS.danger} />
          </View>

          {/* Take Profit Levels */}
          <GlassCard style={styles.tpCard}>
            <Text style={styles.sectionTitle}>Take Profit (TP) Levels</Text>
            <View style={styles.tpRow}>
              <AnalysisCard title="TP 1" value={analysis.take_profit.tp1} color={COLORS.neonGreen} />
              <View style={styles.lockedContainer}>
                <AnalysisCard 
                  title="TP 2" 
                  value={unlocked ? analysis.take_profit.tp2 : 'LOCKED'} 
                  color={unlocked ? COLORS.neonGreen : COLORS.textTertiary} 
                  style={unlocked ? {} : styles.lockedCard}
                />
                <AnalysisCard 
                  title="TP 3" 
                  value={unlocked ? analysis.take_profit.tp3 : 'LOCKED'} 
                  color={unlocked ? COLORS.neonGreen : COLORS.textTertiary} 
                  style={unlocked ? {} : styles.lockedCard}
                />
              </View>
            </View>
            
            {!unlocked && (
              <View style={styles.unlockSection}>
                <Text style={styles.unlockText}>Unlock TP2, TP3, and Risk Level</Text>
                <NeonButton
                  title="Watch Ad to Unlock"
                  onPress={handleUnlockFullAnalysis}
                  variant="secondary"
                  size="medium"
                  icon={<Ionicons name="videocam" size={20} color={COLORS.text} />}
                />
              </View>
            )}
          </GlassCard>

          {/* Risk Level */}
          <GlassCard style={styles.riskCard}>
            <Text style={styles.sectionTitle}>Risk Level</Text>
            <Text style={[styles.riskValue, { color: unlocked ? (analysis.risk_level === 'high' ? COLORS.danger : COLORS.neonGreen) : COLORS.textTertiary }]}>
              {unlocked ? analysis.risk_level.toUpperCase() : 'LOCKED'}
            </Text>
          </GlassCard>

          {/* Analysis Text */}
          <GlassCard style={styles.textCard}>
            <Text style={styles.sectionTitle}>Expert Analysis</Text>
            <Text style={styles.analysisText}>{analysis.analysis_text}</Text>
          </GlassCard>

          {/* Banner Ad */}
          <AdMobBannerComponent unitType="result" />
        </ScrollView>
      </SafeAreaView>
    </GradientBackground>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  scrollContent: {
    padding: SPACING.lg,
    paddingBottom: SPACING.xxl * 2,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: SPACING.lg,
  },
  pageTitle: {
    fontSize: FONT_SIZES.xl,
    fontWeight: 'bold',
    color: COLORS.text,
  },
  sectionTitle: {
    fontSize: FONT_SIZES.lg,
    fontWeight: 'bold',
    color: COLORS.text,
    marginBottom: SPACING.md,
  },
  imageCard: {
    marginBottom: SPACING.lg,
    padding: SPACING.md,
  },
  chartImage: {
    width: '100%',
    aspectRatio: 16 / 9,
    borderRadius: BORDER_RADIUS.md,
    backgroundColor: COLORS.backgroundSecondary,
  },
  metricsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: SPACING.lg,
  },
  analysisCard: {
    width: '48%',
    marginBottom: SPACING.md,
    alignItems: 'center',
    padding: SPACING.sm,
  },
  cardTitle: {
    fontSize: FONT_SIZES.sm,
    color: COLORS.textSecondary,
    marginBottom: SPACING.xs,
  },
  cardValue: {
    fontSize: FONT_SIZES.xl,
    fontWeight: 'bold',
  },
  tpCard: {
    marginBottom: SPACING.lg,
    padding: SPACING.lg,
  },
  tpRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
  },
  lockedContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '48%',
  },
  lockedCard: {
    opacity: 0.5,
  },
  unlockSection: {
    marginTop: SPACING.lg,
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: COLORS.glassBorder,
    paddingTop: SPACING.lg,
  },
  unlockText: {
    color: COLORS.neonPink,
    fontSize: FONT_SIZES.md,
    marginBottom: SPACING.md,
    fontWeight: 'bold',
  },
  riskCard: {
    marginBottom: SPACING.lg,
    padding: SPACING.lg,
    alignItems: 'center',
  },
  riskValue: {
    fontSize: FONT_SIZES.xxl,
    fontWeight: 'bold',
  },
  textCard: {
    marginBottom: SPACING.lg,
    padding: SPACING.lg,
  },
  analysisText: {
    color: COLORS.text,
    fontSize: FONT_SIZES.md,
    lineHeight: 24,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: SPACING.xl,
  },
  errorTitle: {
    fontSize: FONT_SIZES.xxl,
    fontWeight: 'bold',
    color: COLORS.danger,
    marginTop: SPACING.md,
  },
  errorMessage: {
    fontSize: FONT_SIZES.md,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginTop: SPACING.sm,
  },
});
