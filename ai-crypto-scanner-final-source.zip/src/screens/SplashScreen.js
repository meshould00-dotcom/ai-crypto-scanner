import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORS, SHADOWS, FONT_SIZES } from '../constants/theme';
import GradientBackground from '../components/GradientBackground';

export default function SplashScreen({ navigation }) {
  const scaleAnim = useRef(new Animated.Value(0.5)).current;
  const opacityAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.timing(opacityAnim, {
        toValue: 1,
        duration: 500,
        useNativeDriver: true,
      }),
      Animated.spring(scaleAnim, {
        toValue: 1,
        friction: 3,
        useNativeDriver: true,
      }),
      Animated.delay(1500),
    ]).start(() => {
      navigation.replace('MainTabs');
    });
  }, [navigation]);

  return (
    <GradientBackground>
      <View style={styles.container}>
        <Animated.View 
          style={[
            styles.logoContainer,
            { 
              transform: [{ scale: scaleAnim }],
              opacity: opacityAnim,
            }
          ]}
        >
          <Ionicons 
            name="scan-circle" 
            size={100} 
            color={COLORS.neonPurple} 
            style={styles.logoIcon}
          />
        </Animated.View>
        <Animated.Text style={[styles.title, { opacity: opacityAnim }]}>
          AI Crypto Scanner
        </Animated.Text>
        <Animated.Text style={[styles.subtitle, { opacity: opacityAnim }]}>
          Analyze. Trade. Profit.
        </Animated.Text>
      </View>
    </GradientBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoContainer: {
    marginBottom: 20,
    ...SHADOWS.neon,
  },
  logoIcon: {
    // Add a slight glow effect to the icon itself
    textShadowColor: COLORS.neonPurple,
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 10,
  },
  title: {
    fontSize: FONT_SIZES.xxxl,
    fontWeight: 'bold',
    color: COLORS.text,
    marginBottom: 8,
    textShadowColor: COLORS.neonPurple,
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 5,
  },
  subtitle: {
    fontSize: FONT_SIZES.lg,
    color: COLORS.textSecondary,
  },
});
