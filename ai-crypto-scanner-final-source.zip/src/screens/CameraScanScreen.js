import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, SafeAreaView } from 'react-native';
import { Camera } from 'expo-camera';
import { Ionicons } from '@expo/vector-icons';
import { COLORS, SPACING, FONT_SIZES, BORDER_RADIUS } from '../constants/theme';
import NeonButton from '../components/NeonButton';

export default function CameraScanScreen({ navigation }) {
  const [hasPermission, setHasPermission] = useState(null);
  const [isCameraReady, setIsCameraReady] = useState(false);
  const cameraRef = useRef(null);

  useEffect(() => {
    (async () => {
      const { status } = await Camera.requestCameraPermissionsAsync();
      setHasPermission(status === 'granted');
    })();
  }, []);

  const takePicture = async () => {
    if (cameraRef.current) {
      const options = { quality: 0.5, base64: false, skipProcessing: true };
      const photo = await cameraRef.current.takePictureAsync(options);
      
      // Navigate to ResultScreen with the captured image URI
      navigation.replace('Result', { imageUri: photo.uri });
    }
  };

  if (hasPermission === null) {
    return <View style={styles.loadingContainer}><Text style={styles.text}>Requesting camera permission...</Text></View>;
  }
  if (hasPermission === false) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.text}>No access to camera. Please enable it in settings.</Text>
        <NeonButton
          title="Go Back"
          onPress={() => navigation.goBack()}
          variant="outline"
          style={{ marginTop: SPACING.lg }}
        />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Camera
        style={styles.camera}
        ref={cameraRef}
        onCameraReady={() => setIsCameraReady(true)}
        ratio="16:9"
      >
        <SafeAreaView style={styles.topControls}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
            <Ionicons name="close-circle" size={32} color={COLORS.text} />
          </TouchableOpacity>
        </SafeAreaView>

        <View style={styles.overlay}>
          <View style={styles.scanArea}>
            <Text style={styles.scanText}>Align Crypto Chart Here</Text>
            <View style={styles.scanFrame} />
          </View>
        </View>

        <View style={styles.bottomControls}>
          <NeonButton
            title="Capture Chart"
            onPress={takePicture}
            disabled={!isCameraReady}
            loading={!isCameraReady}
            size="large"
            icon={<Ionicons name="scan" size={24} color={COLORS.text} />}
            style={styles.captureButton}
          />
        </View>
      </Camera>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  loadingContainer: {
    flex: 1,
    backgroundColor: COLORS.background,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    color: COLORS.text,
    fontSize: FONT_SIZES.md,
  },
  camera: {
    flex: 1,
  },
  topControls: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    padding: SPACING.md,
    zIndex: 10,
  },
  backButton: {
    alignSelf: 'flex-start',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
  },
  scanArea: {
    width: '90%',
    aspectRatio: 16 / 9,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scanFrame: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    borderWidth: 3,
    borderColor: COLORS.neonPurple,
    borderRadius: BORDER_RADIUS.md,
    opacity: 0.7,
    // Simple neon glow effect
    shadowColor: COLORS.neonPurple,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 10,
    elevation: 10,
  },
  scanText: {
    color: COLORS.text,
    fontSize: FONT_SIZES.lg,
    fontWeight: 'bold',
    backgroundColor: COLORS.overlayDark,
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.xs,
    borderRadius: BORDER_RADIUS.sm,
    marginBottom: SPACING.xl,
  },
  bottomControls: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: SPACING.lg,
    backgroundColor: COLORS.overlayDark,
    alignItems: 'center',
  },
  captureButton: {
    width: '100%',
  },
});
