import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, SafeAreaView, TouchableOpacity, Alert } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import GradientBackground from '../components/GradientBackground';
import GlassCard from '../components/GlassCard';
import NeonButton from '../components/NeonButton';
import { COLORS, SPACING, FONT_SIZES, BORDER_RADIUS } from '../constants/theme';
import { getHistory, deleteHistoryItem, clearHistory } from '../services/storage';

export default function HistoryScreen({ navigation }) {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadHistory = useCallback(async () => {
    setLoading(true);
    const data = await getHistory();
    setHistory(data);
    setLoading(false);
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadHistory();
    }, [loadHistory])
  );

  const handleDelete = (id) => {
    Alert.alert(
      "Delete Scan",
      "Are you sure you want to delete this scan from history?",
      [
        {
          text: "Cancel",
          style: "cancel"
        },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            await deleteHistoryItem(id);
            loadHistory();
          }
        }
      ]
    );
  };

  const handleClearAll = () => {
    Alert.alert(
      "Clear All History",
      "Are you sure you want to delete all scan history? This action cannot be undone.",
      [
        {
          text: "Cancel",
          style: "cancel"
        },
        {
          text: "Clear All",
          style: "destructive",
          onPress: async () => {
            await clearHistory();
            loadHistory();
          }
        }
      ]
    );
  };

  const renderItem = ({ item }) => (
    <GlassCard style={styles.historyItem}>
      <TouchableOpacity 
        style={styles.detailsContainer}
        onPress={() => navigation.navigate('Result', { imageUri: item.imageUri, analysisData: item })}
      >
        <View style={styles.iconContainer}>
          <Ionicons name="analytics" size={24} color={COLORS.neonBlue} />
        </View>
        <View style={styles.textContainer}>
          <Text style={styles.decisionText(item.decision)}>{item.decision || 'N/A'}</Text>
          <Text style={styles.dateText}>{new Date(item.timestamp).toLocaleString()}</Text>
          <Text style={styles.entryText}>Entry: {item.entry || 'N/A'}</Text>
        </View>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => handleDelete(item.id)} style={styles.deleteButton}>
        <Ionicons name="trash" size={20} color={COLORS.danger} />
      </TouchableOpacity>
    </GlassCard>
  );

  if (loading) {
    return (
      <GradientBackground>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading History...</Text>
        </View>
      </GradientBackground>
    );
  }

  return (
    <GradientBackground>
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.header}>
          <Text style={styles.title}>Scan History</Text>
          {history.length > 0 && (
            <NeonButton
              title="Clear All"
              variant="outline"
              size="small"
              onPress={handleClearAll}
              textStyle={{ color: COLORS.danger }}
              style={{ borderColor: COLORS.danger }}
            />
          )}
        </View>
        
        {history.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Ionicons name="time-outline" size={64} color={COLORS.textTertiary} />
            <Text style={styles.emptyText}>No scan history yet.</Text>
            <Text style={styles.emptySubText}>Start scanning charts to see your history here.</Text>
            <NeonButton
              title="Start Scanning"
              onPress={() => navigation.navigate('Home')}
              style={{ marginTop: SPACING.xl }}
            />
          </View>
        ) : (
          <FlatList
            data={history}
            renderItem={renderItem}
            keyExtractor={item => item.id}
            contentContainerStyle={styles.listContent}
          />
        )}
      </SafeAreaView>
    </GradientBackground>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: SPACING.lg,
  },
  title: {
    fontSize: FONT_SIZES.xxl,
    fontWeight: 'bold',
    color: COLORS.text,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: COLORS.text,
    fontSize: FONT_SIZES.lg,
  },
  listContent: {
    paddingHorizontal: SPACING.lg,
    paddingBottom: SPACING.xxl,
  },
  historyItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.md,
    padding: SPACING.md,
  },
  detailsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  iconContainer: {
    marginRight: SPACING.md,
  },
  textContainer: {
    flex: 1,
  },
  decisionText: (decision) => ({
    fontSize: FONT_SIZES.xl,
    fontWeight: 'bold',
    color: decision && decision.toUpperCase() === 'BUY' ? COLORS.neonGreen : (decision && decision.toUpperCase() === 'SELL' ? COLORS.danger : COLORS.neonBlue),
  }),
  dateText: {
    fontSize: FONT_SIZES.sm,
    color: COLORS.textSecondary,
  },
  entryText: {
    fontSize: FONT_SIZES.md,
    color: COLORS.text,
    marginTop: SPACING.xs,
  },
  deleteButton: {
    padding: SPACING.sm,
    borderRadius: BORDER_RADIUS.sm,
    backgroundColor: 'rgba(255, 0, 0, 0.1)',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: SPACING.xl,
  },
  emptyText: {
    fontSize: FONT_SIZES.xl,
    fontWeight: 'bold',
    color: COLORS.text,
    marginTop: SPACING.md,
  },
  emptySubText: {
    fontSize: FONT_SIZES.md,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginBottom: SPACING.xl,
  },
});
