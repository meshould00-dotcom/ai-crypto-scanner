import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, SafeAreaView, Switch, TextInput, ScrollView, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import GradientBackground from '../components/GradientBackground';
import GlassCard from '../components/GlassCard';
import NeonButton from '../components/NeonButton';
import { COLORS, SPACING, FONT_SIZES, BORDER_RADIUS } from '../constants/theme';
import { getSettings, saveSettings } from '../services/storage';

export default function SettingsScreen() {
  const [settings, setSettings] = useState({
    notifications: true,
    autoSave: true,
    apiKey: '',
  });
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    const loadSettings = async () => {
      const loadedSettings = await getSettings();
      setSettings(loadedSettings);
    };
    loadSettings();
  }, []);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await saveSettings(settings);
      Alert.alert("Success", "Settings saved successfully!");
    } catch (error) {
      Alert.alert("Error", "Failed to save settings.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleToggle = (key) => {
    setSettings(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const SettingRow = ({ title, description, children }) => (
    <View style={styles.settingRow}>
      <View style={styles.textContainer}>
        <Text style={styles.settingTitle}>{title}</Text>
        <Text style={styles.settingDescription}>{description}</Text>
      </View>
      <View style={styles.controlContainer}>
        {children}
      </View>
    </View>
  );

  return (
    <GradientBackground>
      <SafeAreaView style={styles.safeArea}>
        <ScrollView contentContainerStyle={styles.scrollContent}>
          <Text style={styles.pageTitle}>Settings</Text>

          <GlassCard style={styles.sectionCard}>
            <Text style={styles.sectionTitle}>General</Text>
            <SettingRow
              title="Auto Save History"
              description="Automatically save all scan results to your history."
            >
              <Switch
                trackColor={{ false: COLORS.textTertiary, true: COLORS.neonPurple }}
                thumbColor={COLORS.text}
                onValueChange={() => handleToggle('autoSave')}
                value={settings.autoSave}
              />
            </SettingRow>
            <SettingRow
              title="Notifications"
              description="Receive notifications for new features and updates."
            >
              <Switch
                trackColor={{ false: COLORS.textTertiary, true: COLORS.neonPurple }}
                thumbColor={COLORS.text}
                onValueChange={() => handleToggle('notifications')}
                value={settings.notifications}
              />
            </SettingRow>
          </GlassCard>

          <GlassCard style={styles.sectionCard}>
            <Text style={styles.sectionTitle}>API Configuration</Text>
            <Text style={styles.inputLabel}>Gemini API Key</Text>
            <TextInput
              style={styles.input}
              placeholder="Enter your custom Gemini API Key"
              placeholderTextColor={COLORS.textSecondary}
              value={settings.apiKey}
              onChangeText={(text) => setSettings(prev => ({ ...prev, apiKey: text }))}
              secureTextEntry
            />
            <Text style={styles.inputDescription}>
              Using your own key can increase rate limits and reliability.
            </Text>
          </GlassCard>

          <NeonButton
            title="Save Settings"
            onPress={handleSave}
            loading={isSaving}
            size="large"
            icon={<Ionicons name="save" size={24} color={COLORS.text} />}
            style={styles.saveButton}
          />
        </ScrollView>
      </SafeAreaView>
    </GradientBackground>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  scrollContent: {
    padding: SPACING.lg,
    paddingBottom: SPACING.xxl,
  },
  pageTitle: {
    fontSize: FONT_SIZES.xxl,
    fontWeight: 'bold',
    color: COLORS.text,
    marginBottom: SPACING.lg,
  },
  sectionCard: {
    marginBottom: SPACING.lg,
    padding: SPACING.lg,
  },
  sectionTitle: {
    fontSize: FONT_SIZES.xl,
    fontWeight: 'bold',
    color: COLORS.neonPurple,
    marginBottom: SPACING.md,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.glassBorder,
    paddingBottom: SPACING.sm,
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: SPACING.md,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.glassBorder,
  },
  textContainer: {
    flex: 1,
    paddingRight: SPACING.md,
  },
  settingTitle: {
    fontSize: FONT_SIZES.md,
    fontWeight: 'bold',
    color: COLORS.text,
  },
  settingDescription: {
    fontSize: FONT_SIZES.sm,
    color: COLORS.textSecondary,
    marginTop: SPACING.xs,
  },
  controlContainer: {
    // For Switch
  },
  inputLabel: {
    fontSize: FONT_SIZES.md,
    fontWeight: 'bold',
    color: COLORS.text,
    marginBottom: SPACING.sm,
  },
  input: {
    backgroundColor: COLORS.backgroundSecondary,
    color: COLORS.text,
    padding: SPACING.md,
    borderRadius: BORDER_RADIUS.md,
    fontSize: FONT_SIZES.md,
    borderWidth: 1,
    borderColor: COLORS.glassBorder,
  },
  inputDescription: {
    fontSize: FONT_SIZES.sm,
    color: COLORS.textTertiary,
    marginTop: SPACING.sm,
  },
  saveButton: {
    marginTop: SPACING.xl,
  },
});
