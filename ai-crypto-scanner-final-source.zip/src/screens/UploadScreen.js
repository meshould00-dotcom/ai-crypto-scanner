import React, { useState } from 'react';
import { View, Text, StyleSheet, SafeAreaView } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import GradientBackground from '../components/GradientBackground';
import NeonButton from '../components/NeonButton';
import GlassCard from '../components/GlassCard';
import { COLORS, SPACING, FONT_SIZES } from '../constants/theme';

export default function UploadScreen({ navigation }) {
  const [status, requestPermission] = ImagePicker.useMediaLibraryPermissions();
  const [isUploading, setIsUploading] = useState(false);

  const pickImage = async () => {
    if (!status?.granted) {
      const permissionResult = await requestPermission();
      if (!permissionResult.granted) {
        alert('Permission to access camera roll is required for this feature!');
        return;
      }
    }

    setIsUploading(true);
    try {
      let result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [16, 9],
        quality: 1,
      });

      if (!result.canceled) {
        // Navigate to ResultScreen with the selected image URI
        navigation.replace('Result', { imageUri: result.assets[0].uri });
      }
    } catch (error) {
      console.error('Image picking failed:', error);
      alert('Failed to pick image. Please try again.');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <GradientBackground>
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.header}>
          <NeonButton
            title="Back"
            variant="outline"
            size="small"
            icon={<Ionicons name="arrow-back" size={20} color={COLORS.neonPurple} />}
            onPress={() => navigation.goBack()}
            style={{ width: 100 }}
          />
        </View>
        <View style={styles.container}>
          <GlassCard style={styles.card}>
            <Ionicons name="images" size={64} color={COLORS.neonBlue} style={styles.icon} />
            <Text style={styles.title}>Upload Chart Image</Text>
            <Text style={styles.subtitle}>
              Select a screenshot of your crypto chart from your gallery for AI analysis.
            </Text>
            <NeonButton
              title="Select from Gallery"
              onPress={pickImage}
              loading={isUploading}
              disabled={isUploading}
              size="large"
              icon={<Ionicons name="cloud-upload" size={24} color={COLORS.text} />}
              style={styles.button}
            />
          </GlassCard>
        </View>
      </SafeAreaView>
    </GradientBackground>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  header: {
    padding: SPACING.md,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: SPACING.lg,
  },
  card: {
    width: '100%',
    alignItems: 'center',
    padding: SPACING.xl,
  },
  icon: {
    marginBottom: SPACING.md,
  },
  title: {
    fontSize: FONT_SIZES.xxl,
    fontWeight: 'bold',
    color: COLORS.text,
    marginBottom: SPACING.sm,
  },
  subtitle: {
    fontSize: FONT_SIZES.md,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginBottom: SPACING.xl,
  },
  button: {
    width: '80%',
    marginTop: SPACING.md,
  },
});
