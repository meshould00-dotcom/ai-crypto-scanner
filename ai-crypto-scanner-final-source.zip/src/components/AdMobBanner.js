import React from 'react';
import { View, StyleSheet } from 'react-native';
import { AdMobBanner } from 'expo-ads-admob';
import { AD_UNITS } from '../services/adMobService';
import { COLORS, BORDER_RADIUS, SPACING } from '../constants/theme';

export default function AdMobBannerComponent({ unitType }) {
  const adUnitID = unitType === 'home' ? AD_UNITS.BANNER_HOME : AD_UNITS.BANNER_RESULT;

  return (
    <View style={styles.container}>
      <AdMobBanner
        bannerSize="fullBanner"
        adUnitID={adUnitID}
        servePersonalizedAds
        onDidFailToReceiveAdWithError={(error) => console.log('AdMob Error:', error)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    height: 50, // Standard banner height
    backgroundColor: COLORS.backgroundSecondary,
    borderRadius: BORDER_RADIUS.md,
    overflow: 'hidden',
    marginVertical: SPACING.md,
  },
});
