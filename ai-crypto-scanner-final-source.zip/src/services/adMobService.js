// AdMob Test IDs - Replace with your real IDs in production
export const AD_UNITS = {
  BANNER_HOME: __DEV__ 
    ? 'ca-app-pub-3940256099942544/6300978111' // Test banner
    : 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX', // Your real banner ID
  
  BANNER_RESULT: __DEV__
    ? 'ca-app-pub-3940256099942544/6300978111' // Test banner
    : 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX', // Your real banner ID
  
  INTERSTITIAL: __DEV__
    ? 'ca-app-pub-3940256099942544/1033173712' // Test interstitial
    : 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX', // Your real interstitial ID
  
  REWARDED: __DEV__
    ? 'ca-app-pub-3940256099942544/5224354917' // Test rewarded
    : 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX', // Your real rewarded ID
};

// Interstitial ad counter
let adCounter = 0;
const AD_FREQUENCY = 3; // Show ad every 3 actions

export const shouldShowInterstitial = () => {
  adCounter++;
  if (adCounter >= AD_FREQUENCY) {
    adCounter = 0;
    return true;
  }
  return false;
};

export const resetAdCounter = () => {
  adCounter = 0;
};
