import axios from 'axios';
import * as FileSystem from 'expo-file-system';

const GEMINI_API_KEY = 'AIzaSyDcjiPpWukfBeYtEMghwb--KBO2j8GSQig'; // Default key, user can override in settings
const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';

const ANALYSIS_PROMPT = `You are an expert crypto technical analyst. Analyze the provided chart image and respond ONLY in JSON format with the following structure:
{
  "trend": "bullish/bearish/neutral",
  "decision": "BUY/SELL/HOLD",
  "entry": "price level",
  "stop_loss": "price level",
  "take_profit": {
    "tp1": "price level",
    "tp2": "price level",
    "tp3": "price level"
  },
  "risk_level": "low/medium/high",
  "analysis_text": "brief explanation of your analysis"
}

Analyze support/resistance levels, trend lines, patterns, and indicators visible in the chart. Be precise and professional.`;

export const analyzeChart = async (imageUri, customApiKey = null) => {
  try {
    // Read image as base64
    const base64 = await FileSystem.readAsStringAsync(imageUri, {
      encoding: FileSystem.EncodingType.Base64,
    });

    const apiKey = customApiKey || GEMINI_API_KEY;
    
    const requestBody = {
      contents: [
        {
          parts: [
            {
              text: ANALYSIS_PROMPT
            },
            {
              inline_data: {
                mime_type: 'image/jpeg',
                data: base64
              }
            }
          ]
        }
      ],
      generationConfig: {
        temperature: 0.4,
        topK: 32,
        topP: 1,
        maxOutputTokens: 2048,
      }
    };

    const response = await axios.post(
      `${GEMINI_API_URL}?key=${apiKey}`,
      requestBody,
      {
        headers: {
          'Content-Type': 'application/json',
        },
      }
    );

    // Extract the text response
    const generatedText = response.data.candidates[0].content.parts[0].text;
    
    // Parse JSON from the response
    const jsonMatch = generatedText.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const analysisData = JSON.parse(jsonMatch[0]);
      return {
        success: true,
        data: analysisData,
        imageUri,
      };
    } else {
      throw new Error('Failed to parse JSON response from AI');
    }
  } catch (error) {
    console.error('Error analyzing chart:', error);
    return {
      success: false,
      error: error.message || 'Failed to analyze chart',
    };
  }
};
